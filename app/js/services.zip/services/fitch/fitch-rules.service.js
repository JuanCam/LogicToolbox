'use strict';

angular.module('logicToolsApp')
    .service('fitchRules', function () {

    });
