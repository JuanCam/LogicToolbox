angular.module('logicToolsApp')
    .factory('FitchStructure', function(Scope) {

      function FitchStructure(props) {
        this.scopes = [];
      }

      FitchStructure.prototype.closeScope = function() {
          this.scopes = _.filter(this.scopes, { isFocused: false });
          this.scopes[this.scopes.length - 1].focus();
      };

      FitchStructure.prototype.openScope = function(headAssumption) {
          var scope = new Scope({ head: headAssumption });

          if (this.scopes.length) {
              this.scopes = _.map(this.scopes, function(scope) {
                  scope.blur();
                  return scope;
              });
          }

          this.scopes.push(scope);
      };

      FitchStructure.prototype.entail = function(assumption) {
          var currentScope = _.filter(this.scopes, 'isFocused');
          currentScope.append(assumption);
      };

      return {
        new: function(props) {
          var fitchProps = props || {};
          return new FitchStructure(fitchProps);
        }
      }
    });
