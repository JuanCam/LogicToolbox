'use strict';

angular.module('logicToolsApp')
    .service('table', function(ALIASES, assumption, formula, negate) {
        var prm, baseAssum;

        this.rebuild = function(premise) {
            var premises, atomicPremises;
            premises = [];
            this.premise = premise;
            baseAssum = assumption.new({
                value: premise,
                level: 0
            });
            reset.call(this);
            atomicPremises = getAtomicPremises(premise);
            this.value = buildAtomicPremises(atomicPremises);
            this.value = _.assign({}, this.value, buildCompoundPremises(premise, this.value));
            this.asocKeys = baseAssum.asocKeys;
        };

        function reset() {
            this.value = {};
            this.asocKeys = {};
            prm = 0;
        }
        reset.call(this);

        function getAtomicPremises(premise) {
            return _.uniq(premise.match(/[^~<=>()&|\s]/g));
        }
        function buildAtomicPremise(value, key) {
            var columns, column, rows;
            columns = _.keys(value);
            rows = Math.pow(2, columns.length);
            column = 0;
            return _.mapValues(value, function (value, key) {
              return getAtomicValue(++column, rows);
            });
        }
        function buildAtomicPremises(atomicPremises) {
            var initialPremises, premisesValues;
            initialPremises = {};
            _.forEach(atomicPremises, function (premise, key) {
                initialPremises[premise] = [];
                premisesValues = buildAtomicPremise(initialPremises, key);
            });
            return premisesValues;
        }
        function buildCompoundPremises(premise, tableValue) {
            var premises, brokenPremise, compoundObject, values, asocKeys;
            values = _.assign({}, tableValue);
            premises = [];
            while (premises) {
                premises = formula.break(premise);
                brokenPremise = (premises) ? premises : [premise];
                compoundObject = buildCompoundPremise(brokenPremise, premise, values);
                premise = compoundObject.reduced;
                values = compoundObject.tableValue;
            }
            return values;
        }
        function buildCompoundPremise(premises, toReduce, tableValue) {
            var reduced, values, label;
            reduced = toReduce.slice();
            values = _.assign({}, tableValue);
            _.each(premises, function(premise, key) {
                label = ALIASES[prm];
                values[label] = getCompoundValue(premise, label, values);
                baseAssum.createAsocKeys(premise, label);
                reduced = reducePremise(reduced, premise, label);
                prm++;
            });
            return {
              reduced: reduced,
              tableValue: values
            };
        }
        function reducePremise(premiseToReduce, premiseToFind, label) {
            var matchPremise;
            premiseToFind = premiseToFind.replace(/[|]/g, '[|]'); //This is special for the 'or' character.
            matchPremise = new RegExp('[(]' + premiseToFind + '[)]', 'g');
            return premiseToReduce.replace(matchPremise, label);
        }
        function getCompoundValue(premise, key, tableValue) {
            var ca, cb, c, a, b, getFormula, atomics, values;
            getFormula = formula.resultFn(premise);
            atomics = premise.match(/\w+|[~]+\w/g);
            values = [];
            ca = negate.column(tableValue, atomics[0]);
            cb = negate.column(tableValue, atomics[1]);
            c = 0;
            while (ca.length > c) {
                a = ca[c];
                b = cb[c];
                values.push(Number(getFormula(a, b)));
                c++;
            }
            return values;
        }
        function getAtomicValue(ncol, nRows) {
            var values, value, row, nchange, sumup;
            values = [];
            value = 0;
            row = 1;
            sumup = 1;
            nchange = Math.pow(2, ncol);
            while (row <= nRows) {
                if (((1 / nchange) * nRows) * sumup < row) {
                    value = 1 - value;
                    sumup++;
                }
                values.push(value);
                row++;
            }
            return values;
        }
    });
